#!/usr/bin/env py -3
def say_it_works():
    print("Imported from Library 1 !!")

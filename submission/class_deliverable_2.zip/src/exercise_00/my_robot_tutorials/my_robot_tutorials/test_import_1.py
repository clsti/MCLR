#!/usr/bin/env py -3
from my_python_libs.python_lib_1 import say_it_works
say_it_works()
